"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const config = {
    preset: "ts-jest",
    testEnvironment: "node",
    moduleFileExtensions: ["ts", "js"],
    testMatch: ["**/*.spec.ts"],
    globals: {
        "ts-jest": {
            isolatedModules: true,
        },
    },
};
exports.default = config;
//# sourceMappingURL=jest.config.js.map