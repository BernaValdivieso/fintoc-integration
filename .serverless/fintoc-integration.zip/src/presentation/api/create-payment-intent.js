"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = exports.createPaymentIntentHandler = void 0;
const yup = __importStar(require("yup"));
const handle_error_1 = require("../../domain/errors/handle-error");
const create_payment_intent_use_case_1 = require("../../domain/use.cases/create-payment-intent.use-case");
const HEADERS = {
    "content-type": "application/json",
};
const requestSchema = yup.object().shape({
    body: yup
        .object()
        .shape({
        amount: yup.number().required(),
    })
        .required(),
});
const CreatePaymentIntentHandler = ({ createPaymentIntentUseCase, }) => async (event) => {
    try {
        await requestSchema.validate({
            body: JSON.parse(event.body),
        }, { abortEarly: false });
        const { amount } = JSON.parse(event.body);
        const product = await createPaymentIntentUseCase.execute({
            amount,
        });
        return {
            statusCode: 201,
            headers: HEADERS,
            body: JSON.stringify(product),
        };
    }
    catch (error) {
        return (0, handle_error_1.handleError)(error);
    }
};
const createPaymentIntentUseCase = (0, create_payment_intent_use_case_1.CreatePaymentIntentUseCase)();
exports.createPaymentIntentHandler = CreatePaymentIntentHandler({
    createPaymentIntentUseCase,
});
exports.handler = exports.createPaymentIntentHandler;
//# sourceMappingURL=create-payment-intent.js.map