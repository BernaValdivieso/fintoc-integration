"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createPaymentIntentGateway = void 0;
const FINTOC_API_KEY = process.env.FINTOC_API_KEY;
const createPaymentIntentGateway = async ({ paymentAmount, }) => {
    const payment_intent = {
        amount: paymentAmount,
        currency: "clp",
        customer_email: "name@example.com",
    };
    const result = await fetch("https://api.fintoc.com/v1/payment_intents", {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            Authorization: `${FINTOC_API_KEY}`,
        },
        body: JSON.stringify(payment_intent),
    });
    return result.json();
};
exports.createPaymentIntentGateway = createPaymentIntentGateway;
//# sourceMappingURL=create-payment-intent.gateway.js.map