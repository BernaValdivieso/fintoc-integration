"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreatePaymentIntentUseCase = void 0;
const create_payment_intent_gateway_1 = require("../gateways/create-payment-intent.gateway");
const CreatePaymentIntentUseCase = () => ({
    execute: async ({ amount }) => {
        const paymentIntent = await (0, create_payment_intent_gateway_1.createPaymentIntentGateway)({
            paymentAmount: amount,
        });
        return paymentIntent;
    },
});
exports.CreatePaymentIntentUseCase = CreatePaymentIntentUseCase;
//# sourceMappingURL=create-payment-intent.use-case.js.map